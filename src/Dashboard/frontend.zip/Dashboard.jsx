import React, { useState, useEffect } from "react";
import "bootstrap-icons/font/bootstrap-icons.css";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  Navbar,
  Nav,
  NavDropdown,
  Container,
  Row,
  Col,
  Card,
  Button,
  Modal,
} from "react-bootstrap";
import axios from "axios";
import { jwtDecode } from "jwt-decode";

import "./Dashboard.css";

function Dashboard() {
  const [isDropdownOpen, setDropdownOpen] = useState(false);

  const [isSidebarOpen, setSidebarOpen] = useState(true);
const [userCount, setUserCount] = useState(0);
  const [departmentCount, setDepartmentCount] = useState(0);
  const [securitygrpCount, setSecuritygrpCount] = useState(0);
  const [userInfo, setUserInfo] = useState({
    full_name: "",
    role: "",
    email: "",
  });
  const [loading, setLoading] = useState(true);
 const [showUpdateModal, setShowUpdateModal] = useState(false);
  const handleShowUpdate = () => setShowUpdateModal(true);
  const handleCloseUpdate = () => setShowUpdateModal(false);
  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const location = useLocation();
  const navigate = useNavigate();
  const mainPage = location.pathname === "/dashboard";

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) throw new Error("No token found, please log in.");

        const decoded = jwtDecode(token);
        setUserInfo({
          full_name: decoded.fullName || "",
          role: decoded.role || "",
          email: decoded.email || "",
        });

        axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;

        const [usersRes, departmentsRes, securitygrpRes] = await Promise.all([
          axios.get("http://localhost:5000/api/users"),
          axios.get("http://localhost:5000/api/dept"),
          axios.get("http://localhost:5000/api/securitygroups"),
          axios.get("http://localhost:5000/api/auth/user")
        ]);

      setUserCount(usersRes.data.users.length);
        setDepartmentCount(departmentsRes.data.departments.length);
        setSecuritygrpCount(securitygrpRes.data.securitygroups.length);
      } catch (err) {
        console.error("Error fetching data:", err.message);
        if (err.response && err.response.status === 401) {
          navigate("/");
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div
      className={`dashboard ${
        isSidebarOpen ? "sidebar-open" : "sidebar-closed"
      }`}
    >
      {/* Sidebar */}
      <div className="sidebar">
        <div className="sidebar-head">
          <img src="/sleek-icon.png" alt="Logo" className="sidebar-logo" />
          <Link to="/dashboard" className="sidebar-link">
            <h2 className="sidebar-header">Dashboard</h2>
          </Link>
        </div>
        <ul className="sidebar-menu">
          <li>
            <Link to="users" className="sidebar-link">
              <i className="fas fa-users"></i> <span>USERS</span>
            </Link>
          </li>
          <li>
            <Link to="regions" className="sidebar-link">
              <i className="fas fa-map-marker-alt"></i> <span>REGIONS</span>
            </Link>
          </li>
          <li>
            <Link to="departments" className="sidebar-link">
              <i className="fas fa-building"></i> <span>DEPARTMENTS</span>
            </Link>
          </li>
          <li>
            <Link to="services" className="sidebar-link">
              <i className="fas fa-cogs"></i> <span>SERVICES</span>
            </Link>
          </li>
          <li>
            <Link to="securitygroup" className="sidebar-link">
              <i className="fas fa-shield-alt"></i> <span>SECURITY GROUP</span>
            </Link>
          </li>
          <li>
            <Link to="appprofile" className="sidebar-link">
              <i className="fas fa-file-alt"></i> <span>APPLICATION PROFILE</span>
            </Link>
          </li>
          <li>
            <Link to="networkprofile" className="sidebar-link">
              <i className="fas fa-network-wired"></i> <span>NETWORK PROFILE</span>
            </Link>
          </li>
          <li>
            <Link to="workloads" className="sidebar-link">
              <i className="fas fa-tasks"></i> <span>WORKLOADS</span>
            </Link>
          </li>
          <li>
            <Link to="appmapping" className="sidebar-link">
              <i className="fas fa-sitemap"></i> <span>APP MAPPING</span>
            </Link>
          </li>
        </ul>
        <div className="sidebar-footer">
          <p>Design & Developed by SmartEdge Technologies © 2025</p>
        </div>
      </div>

      {/* Main content */}
      <div className="main-content">
        <Navbar expand="lg" className="navbar-custom">
          <Container>
            <Navbar.Brand className="custom-navbar-brand">
          <Button variant="primary" onClick={handleShowUpdate}>
                New Updates
              </Button>
            </Navbar.Brand>
            <Navbar.Toggle
              aria-controls="basic-navbar-nav"
              onClick={toggleSidebar}
            />
            <Navbar.Collapse id="basic-navbar-nav">
              <div className="welcome-text">
                <b>WELCOME APPLICATION LIFECYCLE MANAGER</b>
              </div>
              <Nav className="me-5">
                {loading ? (
                  <span>Loading...</span>
                ) : (
                 <NavDropdown
  className="nav-drop"
  show={isDropdownOpen}
  onToggle={(open) => setDropdownOpen(open)}
  title={
    <span className="admin-dropdown d-flex align-items-center">
      <i
        className="bi bi-person-circle"
        style={{
          fontSize: "28px",
          marginRight: "8px",
          color: "#0f26f3ff",
        }}
      ></i>
      <b>
        <small>Welcome </small>
        {userInfo.full_name}
      </b>
    </span>
  }
  id="basic-nav-dropdown"
  align="end"
>
                    <NavDropdown.Item href="#profile">
                      <b>My Profile</b>
                    </NavDropdown.Item>

                    <NavDropdown.Divider />

                    {/* Profile Details Table */}
                    <div className="px-3">
                      <table className="table table-sm mb-0">
                        <tbody>
                          <tr>
                            <th style={{ width: "80px" }}>Name:</th>
                            <td>{userInfo.full_name}</td>
                          </tr>
                          <tr>
                            <th>Role:</th>
                            <td>{userInfo.role}</td>
                          </tr>
                          <tr>
                            <th>Email:</th>
                            <td>{userInfo.email}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>

                    <NavDropdown.Divider />

                    {/* Logout Button */}
                    <NavDropdown.Item
                      onClick={handleLogout}
                      style={{
                        color: "#f8f5f5ff",
                        fontWeight: "bold",
                        background:"red",
                      }}
                      className="logout-btn"
                    >
                      <i
                        className="fas fa-sign-out-alt"
                        style={{
                          marginRight: "8px",
                          fontSize: "16px",
                        }}
                      ></i>
                      Log Out
                    </NavDropdown.Item>
                  </NavDropdown>
                )}
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>
  <Modal show={showUpdateModal} onHide={handleCloseUpdate} centered>
          <Modal.Header closeButton>
            <Modal.Title>Update Information</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <h5>Official Version up to date ****. **. 25</h5>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCloseUpdate}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
        {/* Main dashboard content */}
        <div className={`content-area-wrapper ${isDropdownOpen ? "blurred" : ""}`}>
        <div className="content-area">
          {mainPage && (
            <Container fluid className="mt-5">
              <Row className="mb-4">
                <Col md={3} sm={6}>
                  <Card className="p-3 text-center border-primary">
                    <h4>1</h4>
                    <h5 style={{ color: "gray" }}>Total Applications</h5>
                  </Card>
                </Col>
                <Col md={3} sm={6}>
                  <Card className="p-3 text-center border-primary">
                    <h4>{userCount}</h4>
                    <h5 style={{ color: "gray" }}>Total Users</h5>
                  </Card>
                </Col>
                <Col md={3} sm={6}>
                  <Card className="p-3 text-center border-primary">
                    <h4>{departmentCount}</h4>
                    <h5 style={{ color: "gray" }}>Total Departments</h5>
                  </Card>
                </Col>
                <Col md={3} sm={6}>
                  <Card className="p-3 text-center border-primary">
                    <h4>{securitygrpCount}</h4>
                    <h5 style={{ color: "gray" }}>Security Groups</h5>
                  </Card>
                </Col>
              </Row>
            </Container>
          )}
          <Outlet />
        </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
